#pragma once
#include <Winsock2.h>
#include <windows.h>
#include <WindowsX.h>
#include <iostream>
#include <fstream>
#include <io.h>
#include <sstream> 
using namespace std;

#pragma comment(lib,"Ws2_32.lib");